"""Run the upstream WaterMark API on bytes in Pyodide's temporary filesystem."""
import json
import os

MAX_PIXELS = 12_000_000
os.environ['OPENCV_IO_MAX_IMAGE_PIXELS'] = str(MAX_PIXELS)

import cv2
import numpy as np
from blind_watermark import WaterMark, bw_notes

bw_notes.close()


class InputError(ValueError):
    pass


def read_image(path, flag=cv2.IMREAD_UNCHANGED):
    try:
        img = cv2.imread(path, flag)
    except cv2.error as exc:
        if 'CV_IO_MAX_IMAGE_PIXELS' in str(exc):
            raise InputError('图片超过 1200 万像素，请换一张较小的图片。') from exc
        raise InputError('图片无法解码，请使用有效的 PNG、JPEG 或 BMP 文件。') from exc
    if img is None:
        raise InputError('图片无法解码，请使用有效的 PNG、JPEG 或 BMP 文件。')
    return img


def check_upload_shape(img, bit_count):
    height, width = img.shape[:2]
    if height * width > MAX_PIXELS:
        raise InputError('图片超过 1200 万像素，请换一张较小的图片。')
    capacity = ((height + 1) // 8) * ((width + 1) // 8) - 1
    if bit_count <= 0 or bit_count > capacity:
        raise InputError(f'这张图最多可容纳 {max(0, capacity):,} 位水印，当前需要 {bit_count:,} 位。')


def save_png(image):
    if image.dtype != np.uint8:
        image = cv2.convertScaleAbs(image)
    if not cv2.imwrite('/output.png', image):
        raise RuntimeError('PNG writer failed')


def process(settings):
    embed = settings['operation'] == 'embed'
    text_mode = settings['kind'] == 'text'
    img = read_image('/input.bin', cv2.IMREAD_UNCHANGED if embed else cv2.IMREAD_COLOR)
    engine = WaterMark(password_wm=settings['passwordWm'], password_img=settings['passwordImg'])
    engine.bwm_core.fast_mode = settings['fast']

    if embed:
        if img.dtype != np.uint8:
            raise InputError('请选择 8 位图片，例如普通 JPEG 或 8 位 PNG。')
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        if text_mode:
            content = settings['text']
            if not content or content.startswith('\0'):
                raise InputError('请输入水印文字，首字符不能是 NUL。')
            bit_count = int.from_bytes(content.encode('utf-8'), 'big').bit_length()
            result = {'bits': bit_count}
        else:
            mark = read_image('/mark.bin', cv2.IMREAD_GRAYSCALE)
            height, width = mark.shape
            bit_count = width * height
            result = {'width': width, 'height': height}
        check_upload_shape(img, bit_count)
        engine.read_img(img=img)
        if text_mode:
            engine.read_wm(content, mode='str')
        else:
            engine.read_wm('/mark.bin', mode='img')
        save_png(engine.embed())
        return result

    if text_mode:
        shape = settings['bits']
        check_upload_shape(img, shape)
        try:
            content = engine.extract(embed_img=img, wm_shape=shape, mode='str')
        except ValueError as exc:
            raise InputError('提取结果无法解码。请核对原始位数、两个密码和算法模式。') from exc
        return {'text': content}

    height, width = settings['height'], settings['width']
    check_upload_shape(img, height * width)
    engine.extract(embed_img=img, wm_shape=(height, width), mode='img', out_wm_name='/output.png')
    return {'width': width, 'height': height}


def run_job(settings_json):
    try:
        return json.dumps(process(json.loads(settings_json)), ensure_ascii=False)
    except InputError as exc:
        return json.dumps({'error': str(exc)}, ensure_ascii=False)
